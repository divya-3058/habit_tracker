# 🎪 Habit Carnival WebApp

A **fully gamified** habit tracker built with Flask + SQLite.
Carnival stall cards light up on completion, XP & levels, and alarms that fire **even when the server is off**.

---

## ⚡ Quick Setup — VS Code (5 Steps)

### Step 1 — Open Folder in VS Code
Extract the ZIP → **File → Open Folder** → select `habitcarnival`

### Step 2 — Create Virtual Environment
Open **Terminal** (`Ctrl + backtick`):

```bash
# Windows PowerShell
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

You'll see `(venv)` in the prompt.

### Step 3 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Run the App
```bash
python run.py
```

You should see:
```
* Running on http://127.0.0.1:5000
```

### Step 5 — Open Browser
Go to **http://127.0.0.1:5000**

1. Click **Create an account** → register your hero
2. Login → you're at the carnival dashboard!
3. Add habits with a name and alarm time
4. Click **Allow Alerts** when the banner appears

---

## 🔔 Alarm System — How It Works

### ✅ Server ON + Tab OPEN
JavaScript checks every **8 seconds**.
When the current time matches a habit time:
- Plays a **carnival fanfare** (Web Audio API — no sound file needed)
- Shows an **in-page alarm banner**
- Sends a **browser notification**

### ✅ Server OFF + Tab OPEN
The alarm engine is **100% client-side**. Habits are saved to:
- **IndexedDB** (primary — also readable by Service Worker)
- **localStorage** (backup)

Once the page loads, alarms run completely independently of the server.

### ✅ Tab HIDDEN / MINIMISED
The **Service Worker** runs its own alarm loop that fires at each minute boundary.
It sends a browser notification without needing the tab to be visible.

### ✅ Mobile Browser
- **Wake Lock API** keeps the device screen/timers active
- Works on Chrome Android and Safari iOS
- Add to Home Screen for PWA experience

### ⚠️ Tab FULLY CLOSED + Server OFF
Cannot fire alarms — there's no JavaScript runtime to execute.
**Solution**: Keep the browser tab open in the background. The Service Worker handles the rest.

---

## 🎮 Gamification Features

| Feature | Details |
|---------|---------|
| XP | +10 XP per habit completion |
| Levels | Level up every 100 XP |
| Streak Tracking | Daily consecutive completions |
| Streak Bar | Visual bar fills up per day (max 100%) |
| Lit Stalls | Carnival bulbs glow & blink on completion |
| XP Float | "+10 XP" floats up on completion |
| Level-Up Modal | Confetti explosion + modal popup |
| Particle BG | Animated floating particles |
| Stat Dashboard | Level, XP, Habits, Done Today, Best Streak |

---

## 📂 Folder Structure

```
habitcarnival/
├── run.py                      ← Flask entry point
├── requirements.txt
├── README.md
├── habitcarnival.db            ← SQLite DB (auto-created)
└── app/
    ├── __init__.py             ← App factory
    ├── models.py               ← User + Habit models
    ├── auth/                   ← Blueprint: login/logout
    │   ├── __init__.py
    │   └── routes.py
    ├── habit/                  ← Blueprint: CRUD API
    │   ├── __init__.py
    │   └── routes.py
    ├── carnival/               ← Blueprint: UI + SW serve
    │   ├── __init__.py
    │   └── routes.py
    ├── templates/
    │   ├── base.html
    │   ├── auth/
    │   │   ├── login.html
    │   │   └── register.html
    │   └── carnival/
    │       └── dashboard.html
    └── static/
        ├── manifest.json       ← PWA manifest
        ├── icons/              ← App icons
        │   ├── icon-72.png
        │   ├── icon-192.png
        │   └── icon-512.png
        ├── css/
        │   └── style.css
        └── js/
            ├── sw.js           ← Service Worker (alarms in background)
            ├── sw-reg.js       ← SW registration
            ├── alarm.js        ← Core alarm engine + IndexedDB
            └── dashboard.js    ← Habit CRUD + UI animations
```

---

## 🔧 Troubleshooting

**Port 5000 in use (macOS Monterey+):**
```python
# In run.py, change port:
app.run(debug=True, host='0.0.0.0', port=5001)
```

**Notifications not working:**
- Chrome: Click lock icon in address bar → Notifications → Allow
- Firefox: Click lock icon → Permissions → Allow Notifications
- After allowing, refresh the page

**Alarm sound not playing on first click:**
- Browsers require a user gesture before audio plays
- Click anywhere on the page once, then the alarm will play

**Windows venv activation error:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**`ModuleNotFoundError`:**
Make sure venv is activated (you see `(venv)` in the terminal) before running.

---

## 🎪 Enjoy the Habit Carnival! 🎡
