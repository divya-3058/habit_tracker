from flask import render_template, redirect, url_for, send_from_directory
from flask_login import login_required, current_user
from app.carnival import carnival_bp
from app.models import Habit
from app import db
from datetime import date, timedelta
import os


def _reset_all(habits):
    today = date.today()
    yest  = today - timedelta(days=1)
    for h in habits:
        if h.completed_today and h.last_completed and h.last_completed < today:
            if h.last_completed < yest:
                h.streak = 0
            h.completed_today = False
    db.session.commit()


@carnival_bp.route('/')
def index():
    return redirect(url_for('carnival.dashboard'))


@carnival_bp.route('/dashboard')
@login_required
def dashboard():
    habits = Habit.query.filter_by(user_id=current_user.id)\
                        .order_by(Habit.created_at).all()
    _reset_all(habits)
    return render_template('carnival/dashboard.html',
                           user=current_user, habits=habits)


# Serve sw.js from static/js but at root scope so it can control '/'
@carnival_bp.route('/sw.js')
def service_worker():
    js_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'static', 'js')
    )
    resp = send_from_directory(js_path, 'sw.js',
                               mimetype='application/javascript')
    resp.headers['Service-Worker-Allowed'] = '/'
    resp.headers['Cache-Control']          = 'no-cache'
    return resp


# Serve manifest.json for PWA
@carnival_bp.route('/manifest.json')
def manifest():
    static_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'static')
    )
    return send_from_directory(static_path, 'manifest.json',
                               mimetype='application/manifest+json')
