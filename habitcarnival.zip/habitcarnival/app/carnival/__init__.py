from flask import Blueprint
carnival_bp = Blueprint('carnival', __name__, url_prefix='/')
from app.carnival import routes  # noqa
