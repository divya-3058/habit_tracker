/**
 * ═══════════════════════════════════════════════════════════════
 *  HABIT CARNIVAL — sw.js (Service Worker)
 *  Scope: /   (registered by sw-reg.js, served by Flask /sw.js)
 *
 *  ROLE: Fire browser notifications when the page tab is hidden,
 *        minimised, or the browser is in the background.
 *        Reads habits from its own in-memory cache (updated via
 *        postMessage) AND from the Cache Storage (written by alarm.js).
 *
 *  ALARM LOOP: Uses a recurring setTimeout chain anchored to the
 *  next full minute boundary for accurate firing.
 * ═══════════════════════════════════════════════════════════════
 */

var CACHE_NAME   = 'hc-v2';
var HABITS_KEY   = '/__hc_habits__';  // Cache Storage key for habit list
var _habits      = [];                 // in-memory habit list
var _lastFired   = '';                 // "HH:MM|id" guard

/* ──────────────────────────────────────────────
   Lifecycle
────────────────────────────────────────────── */
self.addEventListener('install', function () {
  self.skipWaiting();
});

self.addEventListener('activate', function (e) {
  e.waitUntil(self.clients.claim());
  scheduleLoop();   // kick off alarm loop immediately
});

/* ──────────────────────────────────────────────
   Messages from the page
────────────────────────────────────────────── */
self.addEventListener('message', function (e) {
  var msg = e.data || {};

  if (msg.type === 'SET_HABITS') {
    _habits = msg.habits || [];
    persistHabits(_habits);          // also persist to Cache Storage
  }

  // Page manually triggers alarm for a specific habit (e.g., page visible alarm)
  if (msg.type === 'ALARM_FIRE') {
    showNotification(msg.name, msg.time);
  }
});

/* ──────────────────────────────────────────────
   Alarm loop — runs inside SW
   Anchors to the next :00 second of each minute
────────────────────────────────────────────── */
function scheduleLoop() {
  var now       = new Date();
  var secsLeft  = 60 - now.getSeconds();
  var msLeft    = secsLeft * 1000 - now.getMilliseconds() + 200; // +200ms buffer

  setTimeout(function () {
    tickAlarm();
    scheduleLoop();    // chain to next minute
  }, Math.max(msLeft, 5000));
}

function tickAlarm() {
  // Load habits if memory is empty
  if (!_habits || !_habits.length) {
    loadHabits().then(checkAlarms);
  } else {
    checkAlarms(_habits);
  }
}

function checkAlarms(habits) {
  if (!habits || !habits.length) return;

  var now  = new Date();
  var hh   = String(now.getHours()).padStart(2, '0');
  var mm   = String(now.getMinutes()).padStart(2, '0');
  var cur  = hh + ':' + mm;

  self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clients) {
    var hasVisible = clients.some(function (c) { return c.visibilityState === 'visible'; });

    habits.forEach(function (h) {
      var hTime = h.time || h.habit_time || '';
      var key   = cur + '|' + String(h.id);

      if (hTime !== cur) return;
      if (_lastFired === key) return;   // already fired this minute
      _lastFired = key;

      if (hasVisible) {
        // Page is open and visible — tell it to fire (with sound)
        clients.forEach(function (c) {
          if (c.visibilityState === 'visible') {
            c.postMessage({ type: 'ALARM_FIRE', name: h.name, time: cur });
          }
        });
      } else {
        // Background/hidden — fire SW notification
        showNotification(h.name, cur);
      }
    });
  });
}

/* ──────────────────────────────────────────────
   Show browser notification
────────────────────────────────────────────── */
function showNotification(name, time) {
  var title = '🎪 Habit Carnival — Alarm!';
  var body  = '⏰ Time for: ' + name + ' (' + time + ') — go conquer it!';

  self.registration.showNotification(title, {
    body:               body,
    icon:               '/static/icons/icon-192.png',
    badge:              '/static/icons/icon-72.png',
    vibrate:            [300, 100, 300, 100, 500],
    requireInteraction: true,
    tag:                'hc-alarm-' + name,
    actions: [
      { action: 'open',    title: '🎯 Open App' },
      { action: 'dismiss', title: '✕ Dismiss'  }
    ]
  }).catch(function (err) { console.warn('[SW] Notification error:', err); });
}

/* ──────────────────────────────────────────────
   Notification click
────────────────────────────────────────────── */
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  if (e.action === 'dismiss') return;

  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clients) {
      if (clients.length > 0) return clients[0].focus();
      return self.clients.openWindow('/dashboard');
    })
  );
});

/* ──────────────────────────────────────────────
   Cache Storage persistence (habits survive SW restart)
────────────────────────────────────────────── */
function persistHabits(habits) {
  caches.open(CACHE_NAME).then(function (cache) {
    var resp = new Response(JSON.stringify(habits), {
      headers: { 'Content-Type': 'application/json' }
    });
    cache.put(HABITS_KEY, resp);
  }).catch(function () {});
}

function loadHabits() {
  return caches.open(CACHE_NAME).then(function (cache) {
    return cache.match(HABITS_KEY).then(function (resp) {
      if (!resp) return [];
      return resp.json().catch(function () { return []; });
    });
  }).catch(function () { return []; });
}

/* ──────────────────────────────────────────────
   Fetch — cache static assets for offline use
────────────────────────────────────────────── */
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;

  var url = new URL(req.url);

  // Only cache /static/ files
  if (!url.pathname.startsWith('/static/')) return;

  e.respondWith(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.match(req).then(function (cached) {
        if (cached) return cached;
        return fetch(req).then(function (resp) {
          if (resp && resp.ok) cache.put(req, resp.clone());
          return resp;
        }).catch(function () { return cached; });
      });
    })
  );
});
