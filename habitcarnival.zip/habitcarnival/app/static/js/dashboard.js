/**
 * dashboard.js — Habit Carnival UI logic
 * Depends on: alarm.js (HC global)
 */
(function () {
  'use strict';

  /* ─── Toast ───────────────────────────────── */
  window.showHCToast = function (msg, type) {
    var wrap = document.getElementById('flashWrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'flashWrap';
      wrap.className = 'flash-wrap';
      document.body.appendChild(wrap);
    }
    var types = { success:'success', danger:'danger', info:'info', warning:'warning' };
    var t = document.createElement('div');
    t.className = 'flash flash-' + (types[type] || 'info');
    t.textContent = msg;
    wrap.appendChild(t);
    setTimeout(function () {
      t.style.animation = 'flashOut .4s forwards';
      setTimeout(function () { t.remove(); }, 400);
    }, 3500);
  };

  /* ─── Modal (level-up / achievements) ────── */
  function openModal(icon, title, body, sub) {
    document.getElementById('mIcon').textContent  = icon  || '🎊';
    document.getElementById('mTitle').textContent = title || 'Level Up!';
    document.getElementById('mBody').textContent  = body  || '';
    document.getElementById('mSub').textContent   = sub   || '';
    document.getElementById('lvlModal').classList.add('modal-open');
    runConfetti();
  }
  window.closeModal = function () {
    document.getElementById('lvlModal').classList.remove('modal-open');
  };

  /* ─── Confetti canvas ─────────────────────── */
  function runConfetti() {
    var canvas = document.getElementById('cfCanvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    var cols = ['#FFD700','#B44FFF','#00E5CC','#FF6BB5','#2ECC71','#FF922B'];
    var bits = Array.from({ length: 70 }, function () {
      return {
        x: Math.random() * canvas.width,
        y: -8,
        r: 3 + Math.random() * 5,
        vx:(Math.random() - .5) * 4,
        vy:2 + Math.random() * 3,
        rot:Math.random() * Math.PI * 2,
        vr:(Math.random() - .5) * .18,
        c: cols[Math.floor(Math.random() * cols.length)]
      };
    });

    var frame = 0;
    (function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      bits.forEach(function (b) {
        b.x += b.vx; b.y += b.vy += .04; b.rot += b.vr;
        ctx.save();
        ctx.translate(b.x, b.y); ctx.rotate(b.rot);
        ctx.fillStyle = b.c;
        ctx.fillRect(-b.r, -b.r, b.r * 2, b.r * 2);
        ctx.restore();
      });
      if (++frame < 110) requestAnimationFrame(draw);
      else ctx.clearRect(0, 0, canvas.width, canvas.height);
    })();
  }

  /* ─── XP Float ────────────────────────────── */
  function xpFloat(card) {
    var s = document.createElement('div');
    s.className = 'xp-float';
    s.textContent = '+10 XP';
    card.style.position = 'relative';
    card.appendChild(s);
    setTimeout(function () { s.remove(); }, 1300);
  }

  /* ─── Emoji picker ────────────────────────── */
  var _emoji = '🎯';
  document.querySelectorAll('.epick').forEach(function (el) {
    el.addEventListener('click', function () {
      document.querySelectorAll('.epick').forEach(function (e) { e.classList.remove('epick-sel'); });
      el.classList.add('epick-sel');
      _emoji = el.dataset.e;
    });
  });

  /* ─── Helper: safe API call ───────────────── */
  function api(url, method, body) {
    var opts = { method: method || 'GET', headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    return fetch(url, opts);
  }

  /* ─── Update XP bar + header ──────────────── */
  function applyUser(u) {
    if (!u) return;
    var bar  = document.getElementById('xpBar');
    var txt  = document.getElementById('xpTxt');
    var badge = document.getElementById('lvlBadge');
    var cLvl = document.getElementById('cLvl');
    var cXP  = document.getElementById('cXP');

    if (bar)  bar.style.width     = u.xp_pct + '%';
    if (txt)  txt.textContent     = u.xp_in + '/100 XP';
    if (badge)badge.textContent   = 'LV ' + u.level;
    if (cLvl) cLvl.textContent   = u.level;
    if (cXP)  cXP.textContent    = u.xp;
  }

  function chipAdd(id, delta) {
    var el = document.getElementById(id);
    if (el) el.textContent = Math.max(0, parseInt(el.textContent || '0') + delta);
  }

  /* ─── Build stall card HTML ───────────────── */
  function stallHTML(h) {
    var pct  = Math.min((h.streak || 0) * 12, 100);
    var done = h.completed ? 'stall-lit' : '';

    return '<div class="stall ' + done + ' stall-new" ' +
           '     id="stall-' + h.id + '" ' +
           '     data-id="'  + h.id + '" ' +
           '     data-name="' + escHtml(h.name) + '" ' +
           '     data-time="' + escHtml(h.time)  + '" ' +
           '     style="--sc:' + h.color + '">' +

      '<div class="bulb-row">' +
        '<span class="bulb"></span>'.repeat(9) +
      '</div>' +

      '<div class="stall-body">' +
        '<div class="stall-emoji">' + h.emoji + '</div>' +
        '<h3 class="stall-name">' + escHtml(h.name) + '</h3>' +
        '<div class="stall-time">⏰ ' + escHtml(h.time) + '</div>' +
        '<div class="streak-wrap">' +
          '<div class="streak-bar" style="width:' + pct + '%"></div>' +
        '</div>' +
        '<div class="stall-meta">' +
          '<span class="stall-streak">🔥 ' + (h.streak || 0) + 'd streak</span>' +
          '<span class="stall-wins">🏆 ' + (h.total || 0) + '</span>' +
        '</div>' +
        '<div class="stall-actions">' +
          '<button class="btn-done' + (h.completed ? ' btn-done-ok' : '') + '" ' +
                  'onclick="completeHabit(' + h.id + ',this)" ' +
                  (h.completed ? 'disabled' : '') + '>' +
            (h.completed ? '✅ Conquered!' : '⚔️ Conquer!') +
          '</button>' +
          '<button class="btn-del" onclick="deleteHabit(' + h.id + ',this)" title="Delete">🗑</button>' +
        '</div>' +
      '</div>' +

      (h.completed ? '<div class="stall-glow"></div><div class="sparkle">✨</div>' : '') +
    '</div>';
  }

  /* ─── Sync habit list to alarm engine ─────── */
  function syncAlarms() {
    var cards = document.querySelectorAll('.stall');
    var list  = [];
    cards.forEach(function (c) {
      list.push({
        id:   c.dataset.id,
        name: c.dataset.name,
        time: c.dataset.time
      });
    });
    if (window.HC) HC.setHabits(list);
  }

  /* ─── ADD HABIT ───────────────────────────── */
  window.addHabit = function () {
    var name = document.getElementById('inName').value.trim();
    var time = document.getElementById('inTime').value;

    if (!name) { showHCToast('Please enter a habit name! 🎪', 'warning'); return; }
    if (!time) { showHCToast('Please choose an alarm time! ⏰', 'warning'); return; }

    var btn = document.getElementById('btnAdd');
    btn.disabled = true; btn.textContent = 'Adding…';

    api('/api/habit/add', 'POST', { name: name, time: time, emoji: _emoji })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) { showHCToast(d.msg || 'Error adding habit.', 'danger'); return; }

        document.getElementById('inName').value = '';
        document.getElementById('inTime').value = '';

        var grid  = document.getElementById('stallGrid');
        var empty = document.getElementById('emptyState');
        if (empty) empty.remove();

        var div = document.createElement('div');
        div.innerHTML = stallHTML(d.habit);
        grid.appendChild(div.firstElementChild);

        chipAdd('cHabits', 1);
        applyUser(d.user);
        syncAlarms();
        showHCToast('🎪 Habit stall added!', 'success');
      })
      .catch(function () { showHCToast('Network error. Check the server.', 'danger'); })
      .finally(function () { btn.disabled = false; btn.textContent = '＋ Add Stall'; });
  };

  /* ─── COMPLETE HABIT ──────────────────────── */
  window.completeHabit = function (id, btn) {
    if (btn.disabled) return;
    btn.disabled = true; btn.textContent = '⏳ …';

    api('/api/habit/complete/' + id, 'POST')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var card = document.getElementById('stall-' + id);

        if (d.already) {
          showHCToast(d.msg, 'info');
          btn.textContent = '✅ Conquered!';
          btn.classList.add('btn-done-ok');
          return;
        }

        if (!d.ok) { showHCToast(d.msg || 'Error.', 'danger'); btn.disabled = false; btn.textContent = '⚔️ Conquer!'; return; }

        // Light up the card
        card.classList.add('stall-lit');
        btn.textContent = '✅ Conquered!';
        btn.classList.add('btn-done-ok');

        // Streak bar
        var pct = Math.min((d.habit.streak || 0) * 12, 100);
        var bar = card.querySelector('.streak-bar');
        if (bar) bar.style.width = pct + '%';

        // Streak text
        var st = card.querySelector('.stall-streak');
        if (st) st.textContent = '🔥 ' + (d.habit.streak || 0) + 'd streak';

        // Wins
        var w = card.querySelector('.stall-wins');
        if (w) w.textContent = '🏆 ' + (d.habit.total || 0);

        // Glow + sparkle if not already there
        if (!card.querySelector('.stall-glow')) {
          var g = document.createElement('div'); g.className = 'stall-glow';
          card.appendChild(g);
        }
        if (!card.querySelector('.sparkle')) {
          var sp = document.createElement('div'); sp.className = 'sparkle'; sp.textContent = '✨';
          card.appendChild(sp);
        }

        applyUser(d.user);
        chipAdd('cDone', 1);

        // Best streak
        var best = parseInt(document.getElementById('cBest').textContent || '0');
        if ((d.habit.streak || 0) > best) {
          document.getElementById('cBest').textContent = d.habit.streak;
        }

        xpFloat(card);
        showHCToast(d.msg, 'success');

        if (d.leveled) {
          openModal('🎊', 'LEVEL UP!',
            'You reached Level ' + d.user.level + '!',
            '🎉 Keep conquering those habits!');
        }

        // Play alarm sound for positive feedback
        if (window.HC) HC.playAlarm();
      })
      .catch(function () {
        btn.disabled = false; btn.textContent = '⚔️ Conquer!';
        showHCToast('Error completing habit.', 'danger');
      });
  };

  /* ─── DELETE HABIT ────────────────────────── */
  window.deleteHabit = function (id, btn) {
    if (!confirm('Remove this habit stall? 🗑')) return;
    btn.disabled = true;

    api('/api/habit/delete/' + id, 'DELETE')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) { showHCToast('Could not delete habit.', 'danger'); btn.disabled = false; return; }
        var card = document.getElementById('stall-' + id);
        card.style.transition = 'opacity .3s, transform .3s';
        card.style.opacity = '0';
        card.style.transform = 'scale(.8)';
        setTimeout(function () {
          card.remove();
          syncAlarms();
          chipAdd('cHabits', -1);
          // Show empty state if no stalls left
          var grid = document.getElementById('stallGrid');
          if (!grid.querySelector('.stall')) {
            grid.innerHTML =
              '<div class="empty-state" id="emptyState">' +
              '  <div class="es-icon">🎪</div>' +
              '  <h3>No stalls yet!</h3>' +
              '  <p>Add your first habit stall above to begin your carnival journey!</p>' +
              '</div>';
          }
        }, 320);
        showHCToast('Habit removed 🗑', 'info');
      })
      .catch(function () { btn.disabled = false; showHCToast('Error deleting habit.', 'danger'); });
  };

  /* ─── Add button click ────────────────────── */
  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('btnAdd');
    if (btn) btn.addEventListener('click', window.addHabit);
    document.getElementById('inName').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') window.addHabit();
    });

    // Initial alarm sync from page data
    syncAlarms();

    // Background canvas particles
    startParticles();
  });

  /* ─── Background particles ────────────────── */
  function startParticles() {
    var canvas = document.getElementById('bgCanvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var W, H, pts = [];
    var COLS = ['#B44FFF','#FFD700','#00E5CC','#FF6BB5','#2ECC71','#FF922B'];

    function resize() {
      W = canvas.width  = window.innerWidth;
      H = canvas.height = window.innerHeight;
    }

    function mkPt() {
      return {
        x: Math.random() * W, y: Math.random() * H + H,
        vx:(Math.random() - .5) * .4,
        vy:-(.5 + Math.random() * .6),
        r: 1 + Math.random() * 2.2,
        a: .08 + Math.random() * .35,
        c: COLS[Math.floor(Math.random() * COLS.length)],
        life:0, max:300 + Math.random() * 300
      };
    }

    resize();
    for (var i = 0; i < 70; i++) {
      var p = mkPt();
      p.y = Math.random() * H;   // stagger start
      p.life = Math.random() * p.max;
      pts.push(p);
    }

    function draw() {
      ctx.clearRect(0, 0, W, H);
      pts.forEach(function (p, i) {
        p.x += p.vx; p.y += p.vy; p.life++;
        var fade = Math.min(p.life / 40, 1) * Math.min((p.max - p.life) / 40, 1);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.c;
        ctx.globalAlpha = p.a * fade;
        ctx.fill();
        if (p.life >= p.max || p.y < -10) pts[i] = mkPt();
      });
      ctx.globalAlpha = 1;
      requestAnimationFrame(draw);
    }
    draw();
    window.addEventListener('resize', resize);
  }

  /* ─── HTML escape ─────────────────────────── */
  function escHtml(s) {
    var d = document.createElement('div');
    d.appendChild(document.createTextNode(String(s)));
    return d.innerHTML;
  }

})();
