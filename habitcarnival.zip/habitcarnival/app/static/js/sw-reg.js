/**
 * sw-reg.js — Register the Service Worker early so it's
 * ready before alarm.js starts the tick loop.
 */
(function () {
  if (!('serviceWorker' in navigator)) return;

  window.addEventListener('load', function () {
    navigator.serviceWorker
      .register('/sw.js', { scope: '/' })
      .then(function (reg) {
        console.log('[HC] SW registered, scope:', reg.scope);

        // Listen for SW messages (alarm triggers, etc.)
        navigator.serviceWorker.addEventListener('message', function (e) {
          var msg = e.data || {};
          if (msg.type === 'ALARM_FIRE' && window.HC) {
            HC.playAlarm();
            HC.showBanner(msg.name, msg.time);
          }
        });
      })
      .catch(function (err) {
        console.warn('[HC] SW registration failed:', err);
      });
  });
})();
