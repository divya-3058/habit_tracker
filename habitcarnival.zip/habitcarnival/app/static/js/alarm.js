/**
 * ═══════════════════════════════════════════════════════════════
 *  HABIT CARNIVAL — alarm.js
 *  Core Alarm Engine
 *
 *  GUARANTEES:
 *   ✅ Server ON  + Tab OPEN   → JS timer fires alarm
 *   ✅ Server OFF + Tab OPEN   → JS timer fires alarm (habits from IndexedDB)
 *   ✅ Server ON  + Tab HIDDEN → Service Worker fires notification
 *   ✅ Server OFF + Tab HIDDEN → Service Worker fires notification
 *   ✅ Mobile browser          → Wake Lock keeps timer alive
 *
 *  HOW IT WORKS:
 *   1. Habits saved to IndexedDB on every change
 *   2. Service Worker reads IndexedDB on its own clock loop
 *   3. Page JS checks every 8 seconds for open-tab alarms
 *   4. Both systems are independent — either fires first
 * ═══════════════════════════════════════════════════════════════
 */
var HC = (function () {
  'use strict';

  /* ─── IndexedDB key ──────────────────────────────────── */
  var IDB_NAME    = 'HabitCarnivalDB';
  var IDB_VERSION = 1;
  var IDB_STORE   = 'habits';
  var LS_BACKUP   = 'hc_habits_backup';   // localStorage fallback

  /* ─── State ──────────────────────────────────────────── */
  var _db       = null;
  var _habits   = [];          // current habit list [{id,name,time}]
  var _firedSet = new Set();   // "HH:MM|id" keys fired this minute

  /* ═══════════════════════════════════════════════════════
     1. INDEXEDDB  (primary storage, readable by SW)
  ══════════════════════════════════════════════════════════ */
  function openDB() {
    return new Promise(function (resolve, reject) {
      if (_db) { resolve(_db); return; }
      if (!window.indexedDB) { resolve(null); return; }

      var req = indexedDB.open(IDB_NAME, IDB_VERSION);

      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE, { keyPath: 'id' });
        }
      };
      req.onsuccess = function (e) { _db = e.target.result; resolve(_db); };
      req.onerror   = function ()  { resolve(null); };
    });
  }

  function saveHabitsIDB(habits) {
    openDB().then(function (db) {
      if (!db) return;
      var tx    = db.transaction(IDB_STORE, 'readwrite');
      var store = tx.objectStore(IDB_STORE);
      store.clear();
      habits.forEach(function (h) { store.put(h); });
    });
    // LocalStorage backup (SW uses this via cache, page uses as fallback)
    try {
      localStorage.setItem(LS_BACKUP, JSON.stringify(habits));
    } catch (e) {}
  }

  function loadHabitsIDB() {
    return openDB().then(function (db) {
      if (!db) return loadHabitsLS();
      return new Promise(function (resolve) {
        var req = db.transaction(IDB_STORE, 'readonly')
                    .objectStore(IDB_STORE).getAll();
        req.onsuccess = function (e) { resolve(e.target.result || []); };
        req.onerror   = function ()  { resolve(loadHabitsLS()); };
      });
    });
  }

  function loadHabitsLS() {
    try {
      return JSON.parse(localStorage.getItem(LS_BACKUP) || '[]');
    } catch (e) { return []; }
  }

  /* ═══════════════════════════════════════════════════════
     2. PUBLIC: update habits (called by dashboard.js)
  ══════════════════════════════════════════════════════════ */
  function setHabits(habits) {
    _habits = habits.map(function (h) {
      return { id: String(h.id), name: h.name, time: h.time || h.habit_time || '' };
    });
    saveHabitsIDB(_habits);
    _tellSW({ type: 'SET_HABITS', habits: _habits });
  }

  /* ═══════════════════════════════════════════════════════
     3. SOUND ENGINE  (Web Audio API — zero files needed)
  ══════════════════════════════════════════════════════════ */
  var _audioCtx = null;

  function getAudioCtx() {
    if (!_audioCtx) {
      var Ctor = window.AudioContext || window.webkitAudioContext;
      if (Ctor) _audioCtx = new Ctor();
    }
    return _audioCtx;
  }

  function playAlarm() {
    var ctx = getAudioCtx();
    if (!ctx) return;

    // Resume context (required after user gesture)
    var doPlay = function () { _playMelody(ctx); };
    if (ctx.state === 'suspended') {
      ctx.resume().then(doPlay);
    } else {
      doPlay();
    }
  }

  function _playMelody(ctx) {
    // Carnival fanfare notes
    var notes = [523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50, 1318.51];
    var durs  = [.14,    .14,    .14,    .28,     .14,    .14,     .45   ];
    var t     = ctx.currentTime + .04;

    notes.forEach(function (freq, i) {
      _note(ctx, freq,      durs[i], t, .42, 'sine');
      _note(ctx, freq * 2,  durs[i], t, .1,  'triangle');
      t += durs[i];
    });

    // Closing chord
    var cEnd = t + .1;
    [659.25, 830.61, 1046.50].forEach(function (f, i) {
      _note(ctx, f, .7, cEnd + i*.1, .28, 'sine');
    });
  }

  function _note(ctx, freq, dur, start, vol, type) {
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, start);
    g.gain.setValueAtTime(0, start);
    g.gain.linearRampToValueAtTime(vol, start + .018);
    g.gain.exponentialRampToValueAtTime(.001, start + dur);
    o.connect(g); g.connect(ctx.destination);
    o.start(start); o.stop(start + dur + .05);
  }

  /* ═══════════════════════════════════════════════════════
     4. IN-PAGE ALARM BANNER
  ══════════════════════════════════════════════════════════ */
  var _bannerTimer = null;

  function showBanner(name, time) {
    var banner = document.getElementById('alarmBanner');
    var title  = document.getElementById('abTitle');
    var sub    = document.getElementById('abSub');
    if (!banner) return;

    title.textContent = '⏰ Time for: ' + name;
    sub.textContent   = 'Scheduled at ' + time + ' — go conquer it!';

    banner.classList.add('alarm-show');
    banner.style.animation = 'none';
    void banner.offsetWidth; // reflow
    banner.style.animation = '';

    clearTimeout(_bannerTimer);
    _bannerTimer = setTimeout(function () { dismissAlarm(); }, 60000);
  }

  function dismissAlarm() {
    var b = document.getElementById('alarmBanner');
    if (b) b.classList.remove('alarm-show');
  }

  /* ═══════════════════════════════════════════════════════
     5. BROWSER NOTIFICATION
  ══════════════════════════════════════════════════════════ */
  function sendNotification(name, time) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
      var n = new Notification('🎪 Habit Carnival Alarm!', {
        body:              '⏰ ' + name + ' — time is ' + time + '. Conquer it!',
        icon:              '/static/icons/icon-192.png',
        badge:             '/static/icons/icon-72.png',
        vibrate:           [300, 100, 300, 100, 500],
        requireInteraction:true,
        tag:               'hc-' + name.replace(/\s/g, '-'),
      });
      n.onclick = function () { window.focus(); n.close(); };
    } catch (e) {}
  }

  /* ═══════════════════════════════════════════════════════
     6. ALARM CHECK LOOP (runs every 8 seconds in page)
  ══════════════════════════════════════════════════════════ */
  function nowHHMM() {
    var d  = new Date();
    var hh = String(d.getHours()).padStart(2, '0');
    var mm = String(d.getMinutes()).padStart(2, '0');
    return hh + ':' + mm;
  }

  function checkNow() {
    var cur = nowHHMM();
    // Clear fired set when minute changes (allow re-fire next day)
    if (!_firedMinute || _firedMinute !== cur) {
      _firedSet = new Set();
      _firedMinute = cur;
    }

    var habits = _habits.length ? _habits : loadHabitsLS();
    habits.forEach(function (h) {
      var habitTime = h.time || h.habit_time || '';
      if (!habitTime) return;
      var key = cur + '|' + h.id;
      if (habitTime === cur && !_firedSet.has(key)) {
        _firedSet.add(key);
        console.log('[HC Alarm] FIRE:', h.name, 'at', cur);
        playAlarm();
        sendNotification(h.name, cur);
        showBanner(h.name, cur);
      }
    });
  }
  var _firedMinute = '';

  /* ═══════════════════════════════════════════════════════
     7. SERVICE WORKER COMMUNICATION
  ══════════════════════════════════════════════════════════ */
  function _tellSW(msg) {
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      try { navigator.serviceWorker.controller.postMessage(msg); } catch (e) {}
    }
  }

  // Listen for SW-triggered alarms (when tab comes back to visible)
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', function (e) {
      var msg = e.data || {};
      if (msg.type === 'ALARM_FIRE') {
        playAlarm();
        showBanner(msg.name, msg.time);
      }
    });
  }

  /* ═══════════════════════════════════════════════════════
     8. WAKE LOCK (keeps mobile screen/timers alive)
  ══════════════════════════════════════════════════════════ */
  var _wl = null;

  function acquireWakeLock() {
    if (!('wakeLock' in navigator)) return;
    navigator.wakeLock.request('screen').then(function (lock) {
      _wl = lock;
      console.log('[HC] Wake Lock acquired');
    }).catch(function () {});

    // Re-acquire when tab becomes visible
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && _wl && _wl.released) {
        navigator.wakeLock.request('screen').then(function (l) { _wl = l; }).catch(function(){});
      }
      if (!document.hidden) checkNow(); // check immediately on visibility
    });
  }

  /* ═══════════════════════════════════════════════════════
     9. NOTIFICATION PERMISSION UI
  ══════════════════════════════════════════════════════════ */
  function renderNotifBanner() {
    var el = document.getElementById('notifBanner');
    if (!el || !('Notification' in window)) return;

    if (Notification.permission === 'default') {
      el.innerHTML =
        '<div class="notif-strip">' +
        '  <span>🔔 Enable notifications to get alarms even when the tab is in background.</span>' +
        '  <button class="btn-notif" id="btnAllowNotif">Allow Alerts</button>' +
        '  <button class="btn-notif" style="background:rgba(255,255,255,.15);color:#fff" ' +
        '    onclick="this.closest(\'.notif-strip\').remove()">✕</button>' +
        '</div>';

      document.getElementById('btnAllowNotif').addEventListener('click', function () {
        Notification.requestPermission().then(function (p) {
          el.innerHTML = '';
          if (p === 'granted') {
            _toast('🔔 Notifications enabled! Alarms will work in the background.', 'success');
          }
        });
      });
    }
  }

  /* ═══════════════════════════════════════════════════════
     10. BOOT
  ══════════════════════════════════════════════════════════ */
  function boot() {
    // Seed from server-rendered data
    if (typeof HC_SEED !== 'undefined' && Array.isArray(HC_SEED.habits)) {
      setHabits(HC_SEED.habits);
    } else {
      // Load from IDB for offline use
      loadHabitsIDB().then(function (h) {
        if (h && h.length) _habits = h;
      });
    }

    renderNotifBanner();
    acquireWakeLock();

    // Start ticker — check every 8 seconds for reliability
    checkNow();
    setInterval(checkNow, 8000);

    // Also check when page gains focus/visibility
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) checkNow();
    });
    window.addEventListener('focus', checkNow);

    console.log('[HC Alarm] Engine started — ticking every 8s');
  }

  // Internal toast (fallback if dashboard.js not loaded yet)
  function _toast(msg, type) {
    if (window.showHCToast) { window.showHCToast(msg, type); return; }
    console.log('[HC Toast]', msg);
  }

  // Public interface
  return {
    boot:         boot,
    setHabits:    setHabits,
    playAlarm:    playAlarm,
    showBanner:   showBanner,
    dismissAlarm: dismissAlarm,
    checkNow:     checkNow,
  };
})();

// Auto-boot when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', HC.boot);
} else {
  HC.boot();
}
