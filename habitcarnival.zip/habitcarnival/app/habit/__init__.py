from flask import Blueprint
habit_bp = Blueprint('habit', __name__, url_prefix='/api/habit')
from app.habit import routes  # noqa
